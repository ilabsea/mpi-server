<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2013-05-22 16:05:59 --> Severity: Warning  --> mysql_connect(): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\mpi_server\system\database\drivers\mysql\mysql_driver.php 73
ERROR - 2013-05-22 16:05:59 --> Unable to connect to the database
