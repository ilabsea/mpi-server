<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2013-06-19 10:12:38 --> Severity: Notice  --> Undefined index: cri_pro_code C:\xampp\htdocs\mpi_server\application\controllers\reports.php 64
