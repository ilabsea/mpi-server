<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2013-06-17 14:37:25 --> 404 Page Not Found --> img
ERROR - 2013-06-17 14:37:25 --> 404 Page Not Found --> img
ERROR - 2013-06-17 14:49:06 --> Severity: Notice  --> Undefined index: cri_pro_code C:\xampp\htdocs\mpi_server\application\controllers\reports.php 64
ERROR - 2013-06-17 16:59:38 --> Severity: Notice  --> Undefined index: cri_pro_code C:\xampp\htdocs\mpi_server\application\controllers\reports.php 64
ERROR - 2013-06-17 17:00:26 --> Severity: Notice  --> Undefined index: cri_pro_code C:\xampp\htdocs\mpi_server\application\controllers\reports.php 64
ERROR - 2013-06-17 17:03:13 --> Severity: Notice  --> Undefined index: cri_pro_code C:\xampp\htdocs\mpi_server\application\controllers\reports.php 64
ERROR - 2013-06-17 17:11:40 --> Severity: Notice  --> Undefined index: cri_pro_code C:\xampp\htdocs\mpi_server\application\controllers\reports.php 64
ERROR - 2013-06-17 17:47:49 --> Severity: Notice  --> Undefined index: cri_pro_code C:\xampp\htdocs\mpi_server\application\controllers\reports.php 64
ERROR - 2013-06-17 21:14:58 --> Severity: Notice  --> Undefined index: cri_pro_code C:\xampp\htdocs\mpi_server\application\controllers\reports.php 64
ERROR - 2013-06-17 21:44:06 --> Severity: Notice  --> Undefined index: cri_pro_code C:\xampp\htdocs\mpi_server\application\controllers\reports.php 64
ERROR - 2013-06-17 21:44:57 --> Severity: Notice  --> Undefined index: cri_pro_code C:\xampp\htdocs\mpi_server\application\controllers\reports.php 64
ERROR - 2013-06-17 21:53:53 --> Severity: Notice  --> Undefined index: cri_pro_code C:\xampp\htdocs\mpi_server\application\controllers\reports.php 64
ERROR - 2013-06-17 22:25:40 --> Severity: Notice  --> Undefined index: cri_pro_code C:\xampp\htdocs\mpi_server\application\controllers\reports.php 64
ERROR - 2013-06-17 22:58:53 --> Severity: Notice  --> Undefined index: cri_pro_code C:\xampp\htdocs\mpi_server\application\controllers\reports.php 64
ERROR - 2013-06-17 23:26:17 --> 404 Page Not Found --> reports/index
ERROR - 2013-06-17 23:26:54 --> Severity: Notice  --> Undefined index: cri_pro_code C:\xampp\htdocs\mpi_server\application\controllers\reports.php 64
ERROR - 2013-06-17 23:42:59 --> Severity: Notice  --> Undefined index: cri_pro_code C:\xampp\htdocs\mpi_server\application\controllers\reports.php 64
ERROR - 2013-06-17 23:59:15 --> Severity: Notice  --> Undefined index: cri_pro_code C:\xampp\htdocs\mpi_server\application\controllers\reports.php 64
