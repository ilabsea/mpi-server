<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2013-06-18 00:06:06 --> Severity: Notice  --> Undefined index: cri_pro_code C:\xampp\htdocs\mpi_server\application\controllers\reports.php 64
ERROR - 2013-06-18 00:19:11 --> Severity: Notice  --> Undefined index: cri_pro_code C:\xampp\htdocs\mpi_server\application\controllers\reports.php 64
